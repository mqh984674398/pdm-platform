from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

# Import model modules so their tables are part of Base.metadata.
import app.core.audit  # noqa: E402,F401
import app.core.auth  # noqa: E402,F401
import app.core.modules  # noqa: E402,F401
import app.datasource.query_service.registry  # noqa: E402,F401
import app.equipment.lifecycle  # noqa: E402,F401
import app.equipment.maintenance  # noqa: E402,F401
import app.equipment.maintenance_impact.service  # noqa: E402,F401
import app.equipment.plant  # noqa: E402,F401
import app.monitoring.alarms.service  # noqa: E402,F401
import app.monitoring.baselines.verified  # noqa: E402,F401
import app.monitoring.features.store  # noqa: E402,F401
import app.monitoring.rules.settings  # noqa: E402,F401
import app.signals.registry  # noqa: E402,F401
from app.core.config import get_settings
from app.core.db import Base

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# The URL comes from server-side settings (PDM_DATABASE_URL), never from alembic.ini.
config.set_main_option("sqlalchemy.url", get_settings().database_url)
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=config.get_main_option("sqlalchemy.url"), target_metadata=target_metadata, literal_binds=True
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    engine = engine_from_config(
        config.get_section(config.config_ini_section, {}), prefix="sqlalchemy.", poolclass=pool.NullPool
    )
    with engine.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
